# Pj

A Pen created on CodePen.

Original URL: [https://codepen.io/izzslick-back/pen/XJJGmpq](https://codepen.io/izzslick-back/pen/XJJGmpq).

Tried Sandhya Subramiam's code challenge for the first time. 
For more designs checkout her profile @https://dribbble.com/sandhya_subram